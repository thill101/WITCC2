var selectedCase = RocketMobileApplication.getEntity("SelectedCase");
window.open(selectedCase.getValue().url, "_system");